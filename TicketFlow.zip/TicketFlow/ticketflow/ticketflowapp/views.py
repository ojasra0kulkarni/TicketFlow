from django.shortcuts import render
from django.http import HttpRequest
# Create your views here.


def loadHome(request):
    return render(request, "ticketflowapp/home.html")